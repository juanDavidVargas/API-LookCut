<?php echo e($slot); ?>

<?php /**PATH /var/www/html/apidespachos/resources/views/vendor/mail/text/table.blade.php ENDPATH**/ ?>