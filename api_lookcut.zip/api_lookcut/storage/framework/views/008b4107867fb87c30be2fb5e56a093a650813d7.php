[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /var/www/html/apidespachos/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>