<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH /var/www/html/apidespachos/resources/views/vendor/mail/html/table.blade.php ENDPATH**/ ?>