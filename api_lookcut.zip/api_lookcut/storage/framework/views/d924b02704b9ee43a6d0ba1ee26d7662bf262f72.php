[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /var/www/html/apidespachos2/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>