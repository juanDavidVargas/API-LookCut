<?php echo e($slot); ?>

<?php /**PATH /var/www/html/apidespachos2/resources/views/vendor/mail/text/table.blade.php ENDPATH**/ ?>