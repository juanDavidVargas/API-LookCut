<?php $__env->startComponent('mail::message'); ?>
### Referencia de Envio: <?php echo e($envio->env_codigo); ?>

### Cliente: <?php echo e($envio->usu_solicitud->usu_nombre); ?>

#### Destinatario
- **Nombre**: <?php echo e($envio->nombre_dest); ?>

- **Dirección**: <?php echo e($envio->direccion_dest); ?>

- **Ciudad**: <?php echo e($envio->municipio->municipio_departamento); ?>, <?php echo e($envio->municipio->dane); ?>

- **Teléfono**: <?php echo e($envio->telefono); ?>

- **Fecha De Solicitud**: <?php echo e($envio->fecha_solicitud); ?>

<?php $__env->startComponent('mail::table'); ?>
| EAN                                            | CANTIDAD            | ESTADO             |
|:----------------------------------------------:|:-------------------:|:------------------:|
<?php $__currentLoopData = $agrupados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
|<?php echo e($item->first()->referencia->codigo_barras); ?>|<?php echo e($item->count()); ?>|<?php echo e($item->first()->estado->est_descripcion); ?>         |
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/html/apidespachos2/resources/views/emails/nuevo_envio.blade.php ENDPATH**/ ?>